
-- 先检查你本地的数据库中，字段名称是否和下面一致？如果不是，请修改字段名称！！

/*
数据库表名和字段:

用户表:

user_name (姓名)，age (年龄)，phone_number (电话号码)，user_id (用户ID) - 主键 (PK)

用户订单表:

user_id (用户ID) - 外键 (FK)，order_id (订单ID) - 主键 (PK)，order_time (订单时间)，order_quantity (订单数量 - 指单品数量)

物料采购表:

material_id (物料ID) - 主键 (PK，假设每条记录的material_id可以唯一标识一次采购事件)， purchase_time (采购时间)，purchase_quantity (采购量)

配方表:

product_id (产品ID)，material_id (物料ID)，recipe_id (配方ID) - 主键 (PK)，material_quantity (物料的量)

*/



-- 第一部分：基础查询 (SELECT, WHERE, ORDER BY, LIMIT, DISTINCT) - 约 7 题## 

-- 1.需求：查看users表中的所有用户数据。
SELECT  XX  FROM 用户表;

-- 2.需求：查看用户订单表中每笔订单的ID和下单时间。
SELECT 
FROM 用户订单表;


-- 3.查询年龄大于25岁的用户姓名和电话号码
SELECT user_name, phone_number
FROM 用户表
WHERE ;

-- 4.查询订单数量超过10的订单信息
SELECT *
FROM 用户订单表
WHERE order_quantity ;

-- 5. 查询所有用户的年龄，并按年龄从大到小排序
SELECT user_name, 
FROM 用户表
; -- DESC 表示降序，从大到小


-- 6. 查询最近5条采购记录的物料ID和采购时间
SELECT 
FROM 物料采购表
ORDER BY  DESC -- 按照采购时间倒序排列
;                     -- 只显示前5条记录

-- 7. 查询配方表中所有不重复的物料ID
SELECT  material_id
FROM 配方表;   -- 注意要去重















-- 第二部分：聚合函数与分组 (COUNT, SUM, AVG, MAX, MIN, GROUP BY, HAVING) - 约 8 题


-- 8.统计用户表中共有多少位用户
SELECT  AS total_users     --  统计 user_id 的数量，要使用count函数，AS 是给结果起个别名
FROM 用户表;

-- 9.计算所有订单的总订单商品数量
SELECT SUM() AS total_order_quantity   -- sum是求和函数
FROM 用户订单表;


-- 10.计算用户的平均年龄
SELECT (age) AS average_age
FROM 用户表;


-- 11.找出订单中下单数量最多的订单ID及其数量

SELECT order_id, order_quantity
FROM 用户订单表
ORDER BY order_quantity DESC -- 按照订单商品数量倒序排列


-- 这种写法更严谨，能找出所有最大数量的订单（如果有多条只显示一条）
SELECT order_id, order_quantity
FROM 用户订单表
ORDER BY order_quantity DESC -- 按照订单商品数量倒序排列
LIMIT ;                     -- 只显示数量最大的一条

-- 12.统计每个用户在本店下单的订单商品总数量，并按照用户id排序：
SELECT user_id, (order_quantity) AS total_items_ordered
FROM 用户订单表
 user_id; -- GROUP BY user_id 表示按 user_id 进行分组统计


-- 13.统计每个物料ID的采购总量
SELECT material_id, (purchase_quantity) AS total_purchase_quantity
FROM 物料采购表
GROUP BY ;





-- 15.统计每天的订单商品总数量（按订单时间）
-- 注意： 这里的日期函数根据你使用的数据库类型可能不同（MySQL是DATE()，PostgreSQL/SQL Server是CAST(order_time AS DATE)或CONVERT(DATE, order_time)）。这里以MySQL为例
SELECT DATE(order_time) AS order_date, -- DATE() 函数提取日期部分
       SUM(order_quantity) AS daily_total_quantity   --每天的销售总量
FROM 用户订单表
GROUP BY order_date
 order_date;


















-- 第三部分：多表查询 (JOIN) - 约 6 题


-- 16.查询所有订单的用户姓名和订单ID
-- 提示：将用户表和用户订单表连接起来，查看每笔订单是谁下的
SELECT u.user_name, o.order_id, o.order_time
FROM 用户表 AS u                 -- 给 用户表 起个别名 u
INNER JOIN 用户订单表 AS o ON ; -- INNER JOIN 连接两个表，ON 指定连接条件



-- 17.查询年龄大于30岁的用户所下的所有订单信息
-- 提示：找出特定年龄段用户的订单
SELECT u.user_name, u.age, o.order_id, o.order_quantity
FROM 用户表 AS u
INNER JOIN 用户订单表 AS o XXX u.user_id = o.user_id
 u.age  30;



-- 18. 查询哪些产品需要使用物料1407621（冰块）
SELECT XXX
    product_id -- 产品ID
FROM
    配方表
WHERE
    material_id = '1407621'; -- 筛选出物料ID为'M001'的记录


    
    
    
  
    
    
    
    
    
    
    
-- 第四部分：子查询与高级筛选 (IN, BETWEEN, LIKE, EXISTS) - 约 4 题
    
-- 19. 查询所有下过订单的用户的姓名和年龄
SELECT user_name, 
FROM 用户表
WHERE user_id IN (SELECT  FROM 用户订单表); -- IN 关键字用于判断一个值是否在子查询的结果集中


-- 20.查询在2025年1月1日到2025年1月3日之间下的订单信息
SELECT order_id, order_time, order_quantity
FROM 用户订单表
WHERE order_time BETWEEN '2024-01-01 00:00:00' AND '2024-01-31 23:59:59';
-- BETWEEN 包括起始和结束日期，注意时间部分
-- 也可以使用：
-- WHERE DATE(order_time) >= '2024-01-01' AND DATE(order_time) <= '2024-01-31';

-- 21.查询用户姓名中包含“刘”字的所有用户信息
-- 提示：使用模糊匹配查找姓名
SELECT user_name, phone_number
FROM 用户表
WHERE  '%刘%'; -- LIKE 用于模糊匹配，% 代表任意数量的字符



-- 拓展题：
-- 22. 找出那些年龄大于平均年龄的用户姓名和年龄
SELECT user_name, age
FROM 
WHERE age  (SELECT (age) FROM ); -- 子查询先计算出平均年龄，然后外层查询用这个结果进行比较



-- 14.找出订单商品总数量超过50的用户的ID和他们的总订单商品数量
SELECT user_id, SUM(order_quantity) AS total_items_ordered
FROM 用户订单表
GROUP BY user_id
HAVING total_items_ordered > 50; -- HAVING 是在 GROUP BY 之后对聚合结果进行过滤